# Galgje

## Te raden woord

|.|.|.|.|.|.|
|-|-|-|-|-|-|
|1|2|3|4|5|6|

## Score
![gallow](./images/1.png)

## Beurten
### A